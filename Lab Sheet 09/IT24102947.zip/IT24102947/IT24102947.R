setwd ("C:\Users\penuk\Desktop\IT24102947")
#1
y <- rnorm (25, mean = 45, sd = 2)

#2
t.test(y, mu = 46, alternative = "less")
